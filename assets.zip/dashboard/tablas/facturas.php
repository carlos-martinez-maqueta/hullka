<div class="table-responsive table-light shadow small-table p-3">
    <table class="table table-sm p-lg-4" id="facturas_tabla">
        <thead>
            <tr>
                <th class="text-center" scope="col">Comprob.</th>
                <th class="text-center" scope="col">Fec. Emisión</th>
                <th class="text-center" scope="col">Forma Pago</th>
                <th class="text-center" scope="col">Ope. Grav.</th>
                <th class="text-center" scope="col">IGV</th>
                <th class="text-center" scope="col">Total</th>
                <th class="text-center" scope="col">Estado</th>
                <th class="text-center" scope="col">Acciones</th>
            </tr>
        </thead>
        <tbody>
            
        </tbody>
    </table>
</div>