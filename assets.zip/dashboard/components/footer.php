<footer class="footer">
    <p class="fs-11 text-muted fw-medium text-uppercase mb-0 copyright">
        <span>Hullka © Todos los derechos reservados por </span>
        <script>
            document.write(new Date().getFullYear());
        </script>
    </p>
    <div class="d-flex align-items-center gap-4">
        <a href="index" target="_blanck" class="fs-11 fw-semibold text-uppercase">INICIO</a>
        <!-- <a href="" target="_blanck" class="fs-11 fw-semibold text-uppercase">2</a>
        <a href="" target="_blanck" class="fs-11 fw-semibold text-uppercase">3</a> -->
    </div>
</footer>